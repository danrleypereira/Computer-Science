# questão 02
print ("questão 02")
x = 5
y = 10

print (x, y)

x = 15
y = x

print (x, y)

# questão 03
print ("questão 03")
a = 5
b = 10

print (a<10 and b > 15)
print (a == 5 and b > 5)
print (a == 5 or b < 5)

# questão 07
print ("questão 07")

a = 50
b = 20
c = a+b
a = 10

print (a, b, c)

# questão 10
print ("questão 10")
numero1 = 25
numero2 = 15
numero3 = 30

if numero1 > numero2:
    print (numero1)
else:
    print (numero2)

